$(function(){
  $('.bxslider').bxSlider({
    mode: 'horizontal',
    captions: true,
    slideWidth: 1600, // tamaño de slider
    auto: true, // para que sea automatico
    keyboardEnabled: true // para que puedas cambiar con
  });
});