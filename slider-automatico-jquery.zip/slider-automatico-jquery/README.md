# Slider Automatico jQuery

A Pen created on CodePen.io. Original URL: [https://codepen.io/FranklinBelen18/pen/MLZgpe](https://codepen.io/FranklinBelen18/pen/MLZgpe).

